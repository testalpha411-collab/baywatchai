import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAlVIv0bAoFyV-9T1Tt1pjyZF4Cv5-F90A",
  authDomain: "baywatch-ai.firebaseapp.com",
  projectId: "baywatch-ai",
  storageBucket: "baywatch-ai.firebasestorage.app",
  messagingSenderId: "912088831195",
  appId: "1:912088831195:web:177cbc261c5d18072d68fe",
  measurementId: "G-X8GM8RGMM8"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
