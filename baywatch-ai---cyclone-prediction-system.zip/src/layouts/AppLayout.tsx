import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { Activity, AlertTriangle, BarChart2, LayoutDashboard, Map, Radio, ShieldAlert, Sun, PhoneCall, X, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { auth } from "@/firebase";
import { signOut } from "firebase/auth";

const navItems = [
  { name: "Executive Overview", path: "/", icon: LayoutDashboard },
  { name: "Impact & Vulnerability", path: "/impact", icon: Map },
  { name: "Predictive Models", path: "/models", icon: BarChart2 },
  { name: "Emergency Response", path: "/emergency", icon: ShieldAlert },
];

export function AppLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const [tooltip, setTooltip] = useState<{ text: string; x: number; y: number } | null>(null);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate("/auth");
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const tooltipEl = target.closest('[data-tooltip]');
      if (tooltipEl) {
        const text = tooltipEl.getAttribute('data-tooltip');
        if (text) {
          setTooltip({ text, x: e.clientX, y: e.clientY });
        }
      } else {
        setTooltip(null);
      }
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <div className="flex h-screen w-full text-slate-100 font-sans overflow-hidden">
      {/* Custom Translucent Gradient Tooltip */}
      {tooltip && (
        <div
          className="fixed z-[9999] pointer-events-none px-3 py-2 text-xs font-medium text-white rounded-lg shadow-2xl backdrop-blur-md bg-gradient-to-br from-sky-900/90 to-teal-900/90 border border-white/20 transition-opacity duration-75"
          style={{
            left: tooltip.x + 15,
            top: tooltip.y + 15,
          }}
        >
          {tooltip.text}
        </div>
      )}

      {/* Sidebar */}
      <aside className="w-64 border-r border-white/10 bg-black/20 backdrop-blur-2xl flex flex-col z-20 shadow-lg">
        <div className="p-6 flex items-center gap-3 border-b border-white/10">
          <div className="bg-gradient-to-br from-teal-400 to-sky-500 p-2 rounded-xl shadow-md relative overflow-hidden flex items-center justify-center">
            <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
            {/* Tamil Nadu Border Abstract Logo */}
            <svg viewBox="0 0 100 120" className="w-6 h-6 text-white relative z-10 drop-shadow-md" fill="currentColor">
              <path d="M25,10 Q45,5 60,15 T85,35 Q90,55 80,75 T55,115 Q45,105 35,85 T15,55 Q10,30 25,10 Z" />
            </svg>
          </div>
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-teal-300 to-sky-300 bg-clip-text text-transparent tracking-tight">BAYWATCH AI</h1>
            <p className="text-[10px] text-sky-300 uppercase tracking-widest font-mono font-semibold">TN Coastal Guard</p>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              data-tooltip={`Navigate to ${item.name}`}
              className={({ isActive }) =>
                cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 relative overflow-hidden",
                  isActive
                    ? "bg-white/10 text-white border border-white/20 shadow-sm"
                    : "text-slate-300 hover:bg-white/5 hover:text-white"
                )
              }
            >
              {({ isActive }) => (
                <>
                  <item.icon className={cn("w-4 h-4 relative z-10", isActive ? "text-teal-400" : "text-slate-400")} />
                  <span className="relative z-10">{item.name}</span>
                </>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <div className="bg-white/5 backdrop-blur-md rounded-xl p-4 border border-white/10 shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-sky-300 uppercase font-semibold">System Status</span>
              <span className="flex h-2.5 w-2.5 rounded-full bg-teal-400 shadow-[0_0_8px_rgba(45,212,191,0.6)] animate-pulse"></span>
            </div>
            <div className="text-sm text-white font-bold">OPTIMAL (Clear)</div>
            <div className="mt-3 space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">Radar Coverage</span>
                <span className="text-teal-400 font-mono font-medium">98%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-300">Satellite Feeds</span>
                <span className="text-teal-400 font-mono font-medium">4/4 Active</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Top Header */}
        <header className="h-16 border-b border-white/10 bg-black/10 backdrop-blur-xl flex items-center justify-between px-6 z-10 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-bold shadow-sm">
              <Sun className="w-3.5 h-3.5 animate-spin-slow" />
              Weather: Sunny / Clear
            </div>
            <span className="text-sm font-mono text-sky-300 font-medium">MONITORING ACTIVE</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <div className="text-sm font-bold text-white">{auth.currentUser?.email || "Operator"}</div>
              <div className="text-xs text-sky-300 font-medium">Coastal Command Center</div>
            </div>
            <button 
              data-tooltip="Click to logout"
              onClick={handleLogout}
              className="w-9 h-9 rounded-full bg-gradient-to-br from-teal-400 to-sky-500 shadow-md flex items-center justify-center border-2 border-white/20 cursor-pointer hover:scale-105 transition-transform"
            >
              <LogOut className="w-4 h-4 text-white" />
            </button>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Floating Emergency Button */}
      <button
        data-tooltip="SOS: Emergency Contacts & Relief Forces"
        onClick={() => setShowEmergencyModal(true)}
        className="fixed bottom-8 right-8 z-50 flex items-center justify-center w-16 h-16 bg-gradient-to-r from-rose-500 to-red-600 text-white rounded-full shadow-[0_0_20px_rgba(225,29,72,0.5)] hover:shadow-[0_0_30px_rgba(225,29,72,0.8)] hover:scale-105 transition-all group"
      >
        <PhoneCall className="w-7 h-7 animate-pulse" />
      </button>

      {/* Emergency Modal */}
      <AnimatePresence>
        {showEmergencyModal && (
          <div className="fixed inset-0 z-[99999] flex items-center justify-center px-4">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setShowEmergencyModal(false)}
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }} 
              animate={{ opacity: 1, scale: 1, y: 0 }} 
              exit={{ opacity: 0, scale: 0.95, y: 20 }} 
              className="relative w-full max-w-md bg-slate-900 border border-rose-500/30 shadow-2xl rounded-2xl overflow-hidden"
            >
              <div className="p-6 bg-gradient-to-br from-rose-500/10 to-transparent">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <div className="p-3 bg-rose-500/20 text-rose-400 rounded-full">
                      <ShieldAlert className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-bold text-white">Emergency Contacts</h2>
                      <p className="text-sm text-slate-300">Tamil Nadu Coastal Guard</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setShowEmergencyModal(false)}
                    className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3">
                  <a href="tel:1046" className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-rose-500/10 hover:border-rose-500/30 transition-colors group">
                    <div className="flex items-center gap-3">
                      <PhoneCall className="w-5 h-5 text-rose-400 group-hover:animate-pulse" />
                      <div>
                        <div className="font-bold text-white">Coast Guard</div>
                        <div className="text-xs text-slate-400">Search & Rescue Operations</div>
                      </div>
                    </div>
                    <span className="text-xl font-mono font-bold text-rose-400">1046</span>
                  </a>

                  <a href="tel:1070" className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-amber-500/10 hover:border-amber-500/30 transition-colors group">
                    <div className="flex items-center gap-3">
                      <AlertTriangle className="w-5 h-5 text-amber-400 group-hover:animate-pulse" />
                      <div>
                        <div className="font-bold text-white">Disaster Management</div>
                        <div className="text-xs text-slate-400">State Emergency Operation Center</div>
                      </div>
                    </div>
                    <span className="text-xl font-mono font-bold text-amber-400">1070</span>
                  </a>

                  <a href="tel:108" className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-teal-500/10 hover:border-teal-500/30 transition-colors group">
                    <div className="flex items-center gap-3">
                      <Activity className="w-5 h-5 text-teal-400 group-hover:animate-pulse" />
                      <div>
                        <div className="font-bold text-white">Ambulance</div>
                        <div className="text-xs text-slate-400">Medical Emergencies</div>
                      </div>
                    </div>
                    <span className="text-xl font-mono font-bold text-teal-400">108</span>
                  </a>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 text-center">
                  <p className="text-xs text-slate-400">
                    Stay calm and provide your exact location when calling.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
