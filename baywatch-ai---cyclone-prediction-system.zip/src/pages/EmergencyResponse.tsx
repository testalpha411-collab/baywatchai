import { AlertTriangle, CheckCircle2, Clock, MapPin, PhoneCall, ShieldAlert, Users, Activity } from "lucide-react";

export function EmergencyResponse() {
  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-white tracking-tight">Emergency Response</h1>
        <p className="text-slate-300">Coordinate evacuation efforts and monitor live feeds from coastal areas.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Evacuation Status */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-teal-400" /> Evacuation Progress
              </h2>
              <span className="text-xs font-bold text-teal-400 bg-teal-500/10 px-3 py-1 rounded-full border border-teal-500/30">Phase 2 Active</span>
            </div>
            
            <div className="space-y-6">
              <EvacuationBar area="Nagapattinam" progress={85} target="12,000" current="10,200" />
              <EvacuationBar area="Cuddalore" progress={60} target="8,500" current="5,100" />
              <EvacuationBar area="Karaikal" progress={40} target="5,000" current="2,000" />
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6">
            <h2 className="text-lg font-bold text-white flex items-center gap-2 mb-6">
              <ShieldAlert className="w-5 h-5 text-rose-400" /> Live Coastal Feeds
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div data-tooltip="View Live Feed: Coastal Area" className="aspect-video bg-black/40 rounded-lg border border-white/10 relative overflow-hidden group cursor-pointer">
                <img src="https://picsum.photos/seed/coast/600/400" alt="Coastal Feed 1" className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity duration-300" referrerPolicy="no-referrer" />
                <div className="absolute top-2 left-2 flex items-center gap-2 bg-black/60 backdrop-blur px-2 py-1 rounded text-[10px] font-mono text-white">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span> LIVE: CAM-01
                </div>
              </div>
              <div data-tooltip="View Live Feed: Port Area" className="aspect-video bg-black/40 rounded-lg border border-white/10 relative overflow-hidden group cursor-pointer">
                <img src="https://picsum.photos/seed/port/600/400" alt="Coastal Feed 2" className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity duration-300" referrerPolicy="no-referrer" />
                <div className="absolute top-2 left-2 flex items-center gap-2 bg-black/60 backdrop-blur px-2 py-1 rounded text-[10px] font-mono text-white">
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span> LIVE: CAM-02
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Hotlines and Logs */}
        <div className="space-y-6">
          <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6">
            <h2 className="text-lg font-bold text-white mb-4">Emergency Hotlines</h2>
            <div className="space-y-3">
              <HotlineCard title="Coast Guard" number="1046" icon={PhoneCall} color="text-rose-400" />
              <HotlineCard title="Disaster Management" number="1070" icon={AlertTriangle} color="text-amber-400" />
              <HotlineCard title="Ambulance" number="108" icon={Activity} color="text-teal-400" />
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6 flex flex-col h-[400px]">
            <h2 className="text-lg font-bold text-white mb-4">Response Log</h2>
            <div className="flex-1 overflow-y-auto pr-2 space-y-4 relative before:absolute before:inset-0 before:ml-2 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-white/10 before:to-transparent">
              <LogEntry time="14:30" text="Relief camp setup completed in Cuddalore." type="success" />
              <LogEntry time="13:45" text="NDRF Team 4 deployed to Karaikal." type="info" />
              <LogEntry time="12:15" text="Power grid secured in vulnerable zones." type="warning" />
              <LogEntry time="11:00" text="Evacuation order issued for coastal villages." type="critical" />
              <LogEntry time="09:30" text="Emergency meeting concluded." type="info" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EvacuationBar({ area, progress, target, current }: any) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-end">
        <div>
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <MapPin className="w-4 h-4 text-slate-400" /> {area}
          </h4>
          <p className="text-xs text-slate-400 mt-1">{current} / {target} evacuated</p>
        </div>
        <span className="text-lg font-bold text-teal-400">{progress}%</span>
      </div>
      <div className="h-2.5 bg-white/10 rounded-full overflow-hidden border border-white/5">
        <div 
          className="h-full bg-gradient-to-r from-teal-500 to-sky-400 transition-all duration-1000 ease-out relative"
          style={{ width: `${progress}%` }}
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
        </div>
      </div>
    </div>
  );
}

function HotlineCard({ title, number, icon: Icon, color }: any) {
  return (
    <div data-tooltip={`Call ${title}: ${number}`} onClick={() => window.alert(`Dialing ${title} at ${number}...`)} className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/10 hover:border-white/30 hover:bg-white/10 transition-colors cursor-pointer group">
      <div className={`p-3 rounded-full bg-white/5 border border-white/10 group-hover:scale-110 transition-transform ${color}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div>
        <h4 className="text-sm font-bold text-white">{title}</h4>
        <p className={`text-lg font-mono font-bold ${color}`}>{number}</p>
      </div>
    </div>
  );
}

function LogEntry({ time, text, type }: any) {
  const icons = {
    success: <CheckCircle2 className="w-4 h-4 text-teal-400" />,
    info: <Clock className="w-4 h-4 text-sky-400" />,
    warning: <AlertTriangle className="w-4 h-4 text-amber-400" />,
    critical: <ShieldAlert className="w-4 h-4 text-rose-400" />
  };

  return (
    <div data-tooltip={`Log Entry: ${time}`} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
      <div className="flex items-center justify-center w-6 h-6 rounded-full border border-white/20 bg-black/40 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10">
        {icons[type as keyof typeof icons]}
      </div>
      <div className="w-[calc(100%-2.5rem)] md:w-[calc(50%-1.5rem)] p-3 rounded-xl bg-white/5 border border-white/10 shadow-sm">
        <div className="flex items-center justify-between mb-1">
          <span className="font-bold text-white text-xs">{text}</span>
        </div>
        <time className="text-[10px] font-mono text-slate-400">{time}</time>
      </div>
    </div>
  );
}
