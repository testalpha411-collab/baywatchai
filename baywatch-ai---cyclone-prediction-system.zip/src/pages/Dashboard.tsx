import { useEffect, useState } from "react";
import { AlertCircle, ArrowRight, BarChart3, Wind, Droplets, Thermometer, Waves, Map, X, Radio, ShieldAlert, Megaphone, CheckCircle2 } from "lucide-react";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { getAIData, CycloneData } from "@/services/ai";
import { motion, AnimatePresence } from "framer-motion";

const mockChartData = [
  { time: "00:00", wind: 65, pressure: 1005 },
  { time: "04:00", wind: 75, pressure: 998 },
  { time: "08:00", wind: 95, pressure: 985 },
  { time: "12:00", wind: 120, pressure: 970 },
  { time: "16:00", wind: 145, pressure: 955 },
  { time: "20:00", wind: 160, pressure: 945 },
  { time: "24:00", wind: 155, pressure: 948 },
];

export function Dashboard() {
  const [aiData, setAiData] = useState<CycloneData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAiDemo, setShowAiDemo] = useState(false);
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  const handleBroadcast = () => {
    setIsBroadcasting(true);
    setTimeout(() => {
      setIsBroadcasting(false);
      setBroadcastSuccess(true);
      setTimeout(() => setBroadcastSuccess(false), 3000);
    }, 2000);
  };

  useEffect(() => {
    async function fetchData() {
      const data = await getAIData();
      setAiData(data);
      setLoading(false);
    }
    fetchData();
  }, []);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold text-white tracking-tight">Executive Overview</h1>
          <p className="text-slate-300">Real-time AI analysis of current meteorological threats.</p>
        </div>
        <div 
          onClick={() => setShowAiDemo(true)}
          className="hidden md:flex items-center gap-2 bg-white/5 backdrop-blur-md border border-white/10 px-4 py-2 rounded-lg shadow-sm cursor-pointer hover:bg-white/10 transition-colors"
        >
          <span className="flex h-2 w-2 rounded-full bg-rose-500 animate-pulse"></span>
          <span className="text-sm font-medium text-slate-200">Live AI Processing</span>
        </div>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Current Intensity"
          value={loading ? "Analyzing..." : aiData?.intensity || "N/A"}
          icon={Wind}
          trend="+15 km/h in last 3 hrs"
          trendUp={true}
          color="text-rose-400"
        />
        <MetricCard
          title="Predicted Landfall"
          value={loading ? "Calculating..." : aiData?.landfall || "N/A"}
          icon={Map}
          trend={`ETA: ${aiData?.eta || "Pending"}`}
          trendUp={false}
          color="text-amber-400"
        />
        <MetricCard
          title="Storm Surge Risk"
          value="High (2.5m)"
          icon={Waves}
          trend="Coastal areas on alert"
          trendUp={true}
          color="text-sky-400"
        />
        <MetricCard
          title="Evacuation Status"
          value="Phase 2"
          icon={AlertCircle}
          trend="45,000 evacuated"
          trendUp={true}
          color="text-teal-400"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white">Intensity Forecast (Wind vs Pressure)</h2>
              <p className="text-sm text-slate-400">AI-generated 24-hour projection</p>
            </div>
            <BarChart3 className="w-5 h-5 text-slate-400" />
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorWind" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', backdropFilter: 'blur(8px)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Area type="monotone" dataKey="wind" stroke="#f43f5e" strokeWidth={3} fillOpacity={1} fill="url(#colorWind)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alerts Panel */}
        <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-white">Active Alerts</h2>
            <button data-tooltip="View all recent alerts" className="text-xs text-teal-400 hover:text-teal-300 font-bold transition-colors">View All</button>
          </div>
          
          <div className="flex-1 overflow-y-auto pr-2 space-y-3">
            <AlertItem 
              level="critical"
              title="Evacuation Order"
              location="Nagapattinam District"
              time="10 mins ago"
            />
            <AlertItem 
              level="warning"
              title="Flash Flood Warning"
              location="Chennai Coastal Areas"
              time="45 mins ago"
            />
            <AlertItem 
              level="info"
              title="Port Operations Suspended"
              location="Ennore Port"
              time="2 hours ago"
            />
             <AlertItem 
              level="warning"
              title="High Wind Alert"
              location="Cuddalore"
              time="3 hours ago"
            />
          </div>
        </div>
      </div>

      {/* Evacuation & Response Planning Section */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
          <div>
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-6 h-6 text-rose-400" />
              Disaster Response & Evacuation Planning
            </h2>
            <p className="text-sm text-slate-400 mt-1">Coordinate early warning alerts and manage coastal community evacuations.</p>
          </div>
          <button 
            onClick={handleBroadcast}
            disabled={isBroadcasting || broadcastSuccess}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              broadcastSuccess 
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/50" 
                : isBroadcasting
                  ? "bg-rose-500/50 text-white cursor-not-allowed"
                  : "bg-rose-500 hover:bg-rose-600 text-white shadow-[0_0_20px_rgba(244,63,94,0.3)] hover:shadow-[0_0_30px_rgba(244,63,94,0.5)]"
            }`}
          >
            {broadcastSuccess ? (
              <>
                <CheckCircle2 className="w-5 h-5" />
                Alerts Broadcasted
              </>
            ) : isBroadcasting ? (
              <>
                <Radio className="w-5 h-5 animate-pulse" />
                Transmitting...
              </>
            ) : (
              <>
                <Megaphone className="w-5 h-5" />
                Broadcast Emergency Alert
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <EvacuationZone 
            zone="Zone A (High Risk)"
            communities="Nagapattinam, Karaikal"
            population="125,000"
            status="Evacuation Ordered"
            progress={85}
            color="rose"
          />
          <EvacuationZone 
            zone="Zone B (Medium Risk)"
            communities="Cuddalore, Puducherry"
            population="340,000"
            status="Standby / Prepare"
            progress={40}
            color="amber"
          />
          <EvacuationZone 
            zone="Zone C (Low Risk)"
            communities="Chennai South, Chengalpattu"
            population="850,000"
            status="Monitoring"
            progress={10}
            color="sky"
          />
        </div>
      </div>

      <AnimatePresence>
        {showAiDemo && <AiProcessingModal onClose={() => setShowAiDemo(false)} />}
      </AnimatePresence>
    </div>
  );
}

function MetricCard({ title, value, icon: Icon, trend, trendUp, color }: any) {
  return (
    <div data-tooltip={`Metric: ${title}`} className={`bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-5 flex flex-col gap-4 relative overflow-hidden group hover:bg-white/10 transition-colors`}>
      <div className="absolute -right-6 -top-6 w-24 h-24 bg-white/5 rounded-full blur-2xl group-hover:bg-white/10 transition-colors"></div>
      <div className="flex items-start justify-between relative z-10">
        <div className="space-y-1">
          <p className="text-sm font-medium text-slate-300">{title}</p>
          <p className="text-2xl font-bold text-white tracking-tight">{value}</p>
        </div>
        <div className={`p-2 rounded-xl bg-white/5 border border-white/10 ${color}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <div className="flex items-center gap-2 text-xs relative z-10">
        <span className={trendUp ? "text-rose-400 font-medium" : "text-teal-400 font-medium"}>
          {trend}
        </span>
      </div>
    </div>
  );
}

function AlertItem({ level, title, location, time }: any) {
  const colors = {
    critical: "border-rose-500/30 bg-rose-500/10 text-rose-400",
    warning: "border-amber-500/30 bg-amber-500/10 text-amber-400",
    info: "border-sky-500/30 bg-sky-500/10 text-sky-400"
  };

  return (
    <div data-tooltip={`Alert: ${title} at ${location}`} className={`flex gap-3 items-start p-3 rounded-xl border shadow-sm hover:bg-white/5 transition-all cursor-pointer ${colors[level as keyof typeof colors]}`}>
      <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
      <div>
        <h4 className="text-sm font-bold text-white">{title}</h4>
        <p className="text-xs text-slate-300 mt-0.5">{location}</p>
        <p className="text-[10px] text-slate-400 mt-1 font-medium">{time}</p>
      </div>
    </div>
  );
}

function EvacuationZone({ zone, communities, population, status, progress, color }: any) {
  const colorMap = {
    rose: "bg-rose-500",
    amber: "bg-amber-500",
    sky: "bg-sky-500"
  };
  
  const textMap = {
    rose: "text-rose-400",
    amber: "text-amber-400",
    sky: "text-sky-400"
  };

  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex flex-col gap-3">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-bold text-white">{zone}</h3>
          <p className="text-xs text-slate-400 mt-0.5">{communities}</p>
        </div>
        <span className={`text-xs font-bold px-2 py-1 rounded-md bg-white/5 border border-white/10 ${textMap[color as keyof typeof textMap]}`}>
          {status}
        </span>
      </div>
      
      <div className="mt-2">
        <div className="flex justify-between text-xs mb-1">
          <span className="text-slate-400">Evacuation Progress</span>
          <span className="text-white font-medium">{progress}%</span>
        </div>
        <div className="w-full bg-slate-800 rounded-full h-1.5">
          <div 
            className={`h-1.5 rounded-full ${colorMap[color as keyof typeof colorMap]}`} 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>
      
      <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
        <AlertCircle className="w-3 h-3" />
        <span>Est. Population: {population}</span>
      </div>
    </div>
  );
}

function AiProcessingModal({ onClose }: { onClose: () => void }) {
  const [logs, setLogs] = useState<string[]>([]);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    const logSequence = [
      "> Initializing Baywatch AI Core v3.1.4...",
      "> Establishing secure handshake with INSAT-3D...",
      "> [SUCCESS] Satellite telemetry stream connected.",
      "> Ingesting regional atmospheric pressure data (hPa)...",
      "> Analyzing sea surface temperature anomalies...",
      "> Running ensemble predictive models (GFS, ECMWF)...",
      "> [WARNING] High thermal energy detected in Bay of Bengal.",
      "> Calculating storm surge probabilities for coastal districts...",
      "> Updating trajectory matrix...",
      "> [COMPLETE] Real-time threat assessment updated."
    ];

    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex < logSequence.length) {
        setLogs(prev => [...prev, logSequence[currentIndex]]);
        currentIndex++;
      } else {
        setIsComplete(true);
        clearInterval(interval);
      }
    }, 600);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center px-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }} 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.95, y: 20 }} 
        className="relative w-full max-w-2xl bg-[#0a0a0a] border border-teal-500/30 shadow-[0_0_40px_rgba(45,212,191,0.1)] rounded-xl overflow-hidden font-mono"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 bg-white/5">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-rose-500"></div>
            <div className="w-3 h-3 rounded-full bg-amber-500"></div>
            <div className="w-3 h-3 rounded-full bg-teal-500"></div>
            <span className="ml-2 text-xs text-slate-400">ai-core-terminal ~ root</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="p-6 h-[400px] overflow-y-auto flex flex-col gap-2 text-sm text-teal-400">
          {logs.map((log, i) => (
            <motion.div 
              key={i} 
              initial={{ opacity: 0, x: -10 }} 
              animate={{ opacity: 1, x: 0 }}
              className={log?.includes("[WARNING]") ? "text-amber-400" : log?.includes("[SUCCESS]") || log?.includes("[COMPLETE]") ? "text-sky-400 font-bold" : ""}
            >
              {log}
            </motion.div>
          ))}
          {!isComplete && (
            <motion.div 
              animate={{ opacity: [1, 0] }} 
              transition={{ repeat: Infinity, duration: 0.8 }}
              className="w-2 h-4 bg-teal-400 mt-1"
            />
          )}
        </div>
      </motion.div>
    </div>
  );
}
