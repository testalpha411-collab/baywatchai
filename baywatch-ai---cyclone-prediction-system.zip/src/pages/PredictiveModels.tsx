import { Activity, BarChart2, TrendingUp, Zap } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";

const predictiveData = [
  { day: "Day 1", modelA: 120, modelB: 115, modelC: 125 },
  { day: "Day 2", modelA: 140, modelB: 135, modelC: 150 },
  { day: "Day 3", modelA: 165, modelB: 155, modelC: 175 },
  { day: "Day 4", modelA: 150, modelB: 145, modelC: 160 },
  { day: "Day 5", modelA: 110, modelB: 120, modelC: 105 },
];

export function PredictiveModels() {
  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold text-white tracking-tight">Predictive Models</h1>
        <p className="text-slate-300">Compare different AI and meteorological models for storm progression.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <ModelCard 
          title="Global Forecast System (GFS)"
          accuracy="89%"
          prediction="Landfall at Cuddalore"
          icon={BarChart2}
          color="text-sky-400"
        />
        <ModelCard 
          title="European Model (ECMWF)"
          accuracy="92%"
          prediction="Landfall at Nagapattinam"
          icon={Activity}
          color="text-teal-400"
        />
        <ModelCard 
          title="Baywatch AI Ensemble"
          accuracy="96%"
          prediction="Landfall at Karaikal"
          icon={Zap}
          color="text-amber-400"
        />
      </div>

      <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-white">Wind Speed Divergence (km/h)</h2>
            <p className="text-sm text-slate-400">Comparing model predictions over the next 5 days</p>
          </div>
          <TrendingUp className="w-5 h-5 text-slate-400" />
        </div>
        
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={predictiveData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="day" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(15, 23, 42, 0.9)', backdropFilter: 'blur(8px)', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
                itemStyle={{ color: '#e2e8f0' }}
              />
              <Line type="monotone" dataKey="modelA" name="GFS" stroke="#38bdf8" strokeWidth={3} dot={{ r: 4, fill: '#38bdf8' }} />
              <Line type="monotone" dataKey="modelB" name="ECMWF" stroke="#2dd4bf" strokeWidth={3} dot={{ r: 4, fill: '#2dd4bf' }} />
              <Line type="monotone" dataKey="modelC" name="Baywatch AI" stroke="#fbbf24" strokeWidth={4} dot={{ r: 6, fill: '#fbbf24' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="flex items-center justify-center gap-6 mt-6">
          <div data-tooltip="Global Forecast System" className="flex items-center gap-2 text-sm text-slate-300">
            <span className="w-3 h-3 rounded-full bg-sky-400"></span> GFS
          </div>
          <div data-tooltip="European Centre for Medium-Range Weather Forecasts" className="flex items-center gap-2 text-sm text-slate-300">
            <span className="w-3 h-3 rounded-full bg-teal-400"></span> ECMWF
          </div>
          <div data-tooltip="Our proprietary AI ensemble model" className="flex items-center gap-2 text-sm font-bold text-white">
            <span className="w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]"></span> Baywatch AI
          </div>
        </div>
      </div>
    </div>
  );
}

function ModelCard({ title, accuracy, prediction, icon: Icon, color }: any) {
  return (
    <div data-tooltip={`Model Status: ${title}`} className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-5 flex items-center gap-4 hover:bg-white/10 transition-colors">
      <div className={`p-3 rounded-xl bg-white/5 border border-white/10 ${color}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <h3 className="text-sm font-bold text-white">{title}</h3>
        <div className="flex items-center gap-2 mt-1">
          <span className="text-xs text-slate-400">Accuracy:</span>
          <span className={`text-xs font-bold ${color}`}>{accuracy}</span>
        </div>
        <p className="text-xs text-slate-300 mt-1">{prediction}</p>
      </div>
    </div>
  );
}
