import { useEffect, useState } from "react";
import { AlertCircle, Layers, Maximize2, Navigation, Radar } from "lucide-react";
import { MapContainer, TileLayer, Polyline, Marker, Popup, Circle, useMap } from "react-leaflet";
import { getAIData, CycloneData } from "@/services/ai";
import L from "leaflet";

// Fix for default marker icon in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const userIcon = L.divIcon({
  className: 'bg-transparent',
  html: `<div class="w-4 h-4 bg-teal-400 border-2 border-white rounded-full shadow-[0_0_15px_rgba(45,212,191,0.8)] animate-pulse -ml-2 -mt-2"></div>`,
  iconSize: [0, 0],
  iconAnchor: [0, 0]
});

function MapBounds({ path, userLoc }: { path: [number, number][], userLoc: [number, number] | null }) {
  const map = useMap();
  useEffect(() => {
    const points = [...path];
    if (userLoc) points.push(userLoc);
    
    if (points.length > 0) {
      const bounds = L.latLngBounds(points);
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [path, userLoc, map]);
  return null;
}

export function ImpactMap() {
  const [aiData, setAiData] = useState<CycloneData | null>(null);
  const [userLoc, setUserLoc] = useState<[number, number] | null>(null);
  const [radarActive, setRadarActive] = useState(true);

  useEffect(() => {
    async function fetchData() {
      const data = await getAIData();
      setAiData(data);
    }
    fetchData();

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLoc([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.error("Error getting location", error);
          setUserLoc([13.0827, 80.2707]); // Fallback to Chennai
        }
      );
    } else {
      setUserLoc([13.0827, 80.2707]);
    }
  }, []);

  // Default center
  const mapCenter: [number, number] = userLoc || [13.0, 84.0];

  return (
    <div className="space-y-6 h-full flex flex-col max-w-7xl mx-auto">
      <div className="flex flex-col gap-2 shrink-0">
        <h1 className="text-3xl font-bold text-white tracking-tight">Impact & Vulnerability</h1>
        <p className="text-slate-300">Real-time location tracking, radar, and AI-predicted storm trajectory.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 flex-1 min-h-0">
        {/* Sidebar Controls */}
        <div className="lg:col-span-1 space-y-4 overflow-y-auto pr-2">
          <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-5">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-400" /> Map Layers
            </h3>
            <div className="space-y-3">
              <LayerToggle label="Live Radar" active={radarActive} onChange={() => setRadarActive(!radarActive)} color="bg-green-400" />
              <LayerToggle label="Cyclone Trajectory (AI)" active={true} color="bg-cyan-400" />
              <LayerToggle label="Population Density" active={true} color="bg-sky-400" />
              <LayerToggle label="Storm Surge Risk" active={true} color="bg-rose-400" />
            </div>
          </div>

          <div className="bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl p-5">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400" /> Vulnerability Assessment
            </h3>
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Coastal Pop. in High Risk</span>
                  <span className="text-rose-400 font-bold">1.2M+</span>
                </div>
                <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <div className="h-full bg-rose-500 w-[85%]"></div>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Major Cities Affected</span>
                  <span className="text-amber-400 font-bold">{aiData?.landfall || 'Calculating...'}</span>
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">Potential Storm Surge</span>
                  <span className="text-sky-300 font-bold">2.5m (Est.)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Map Area */}
        <div className="lg:col-span-3 bg-white/5 backdrop-blur-md border border-white/10 shadow-lg rounded-2xl relative overflow-hidden flex flex-col min-h-[500px] z-0">
          <MapContainer center={mapCenter} zoom={6} className="w-full h-full" zoomControl={false}>
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            />
            
            {/* Render AI Predicted Path */}
            {aiData?.path && aiData.path.length > 0 && (
              <>
                <MapBounds path={aiData.path} userLoc={userLoc} />
                <Polyline positions={aiData.path} color="cyan" weight={4} dashArray="5, 10" />
                
                {/* Current Cyclone Location Marker */}
                <Marker position={aiData.path[0]}>
                  <Popup>
                    <div className="font-bold text-sky-900">Cyclone Eye</div>
                    <div className="text-xs text-sky-600">Intensity: {aiData.intensity}</div>
                  </Popup>
                </Marker>

                {/* Radar Effect around Cyclone */}
                {radarActive && (
                  <Circle 
                    center={aiData.path[0]} 
                    radius={150000} 
                    pathOptions={{ color: '#22c55e', fillColor: '#22c55e', fillOpacity: 0.1, weight: 1, className: 'animate-ping' }} 
                  />
                )}

                {/* Landfall Marker */}
                <Marker position={aiData.path[aiData.path.length - 1]}>
                  <Popup>
                    <div className="font-bold text-rose-600">Predicted Landfall</div>
                    <div className="text-xs text-sky-600">ETA: {aiData.eta}</div>
                  </Popup>
                </Marker>

                {/* Impact Zones around landfall */}
                <Circle center={aiData.path[aiData.path.length - 1]} radius={100000} pathOptions={{ color: '#ef4444', fillColor: '#ef4444', fillOpacity: 0.2 }} />
                <Circle center={aiData.path[aiData.path.length - 1]} radius={200000} pathOptions={{ color: '#f59e0b', fillColor: '#f59e0b', fillOpacity: 0.1 }} />
              </>
            )}

            {/* User Real-time Location */}
            {userLoc && (
              <Marker position={userLoc} icon={userIcon}>
                <Popup>
                  <div className="font-bold text-sky-900">Your Location</div>
                  <div className="text-xs text-sky-600">Real-time tracking active</div>
                </Popup>
              </Marker>
            )}
            
            {/* User Location Radar */}
            {userLoc && radarActive && (
               <Circle 
                 center={userLoc} 
                 radius={20000} 
                 pathOptions={{ color: '#38bdf8', fillColor: '#38bdf8', fillOpacity: 0.2, weight: 2, className: 'animate-pulse' }} 
               />
            )}
          </MapContainer>

          {/* Map Controls Overlay */}
          <div className="absolute top-4 right-4 z-[400] flex flex-col gap-2">
            <button data-tooltip="Maximize map view" className="p-2 bg-black/40 backdrop-blur border border-white/20 shadow-sm rounded-lg text-white hover:bg-black/60 transition-colors">
              <Maximize2 className="w-4 h-4" />
            </button>
            <button 
              data-tooltip="Recenter map" 
              className="p-2 bg-black/40 backdrop-blur border border-white/20 shadow-sm rounded-lg text-white hover:bg-black/60 transition-colors"
            >
              <Navigation className="w-4 h-4" />
            </button>
            <button 
              data-tooltip="Toggle Radar" 
              onClick={() => setRadarActive(!radarActive)}
              className={`p-2 backdrop-blur border shadow-sm rounded-lg transition-colors ${radarActive ? 'bg-green-500/40 border-green-400 text-green-300' : 'bg-black/40 border-white/20 text-white hover:bg-black/60'}`}
            >
              <Radar className="w-4 h-4" />
            </button>
          </div>

          {/* Map Legend */}
          <div className="absolute bottom-4 left-4 z-[400] bg-black/60 backdrop-blur border border-white/20 shadow-sm rounded-lg p-3">
            <div className="text-[10px] font-mono text-sky-300 font-bold uppercase mb-2">Impact Zone Summary</div>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-200">
              <span className="w-3 h-3 rounded-full bg-rose-500/50 border border-rose-500"></span> High Risk (100km)
            </div>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-200 mt-1">
              <span className="w-3 h-3 rounded-full bg-amber-500/50 border border-amber-500"></span> Moderate Risk (200km)
            </div>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-200 mt-1">
              <span className="w-3 h-3 rounded-full bg-green-500/50 border border-green-500"></span> Radar Active
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LayerToggle({ label, active, color, onChange }: { label: string, active: boolean, color: string, onChange?: () => void }) {
  return (
    <label data-tooltip={`Toggle layer: ${label}`} className="flex items-center justify-between cursor-pointer group" onClick={onChange}>
      <div className="flex items-center gap-3">
        <div className={`w-3 h-3 rounded-sm ${color} ${active ? 'opacity-100' : 'opacity-30'}`}></div>
        <span className={`text-sm font-medium ${active ? 'text-white' : 'text-slate-400'} group-hover:text-sky-200 transition-colors`}>{label}</span>
      </div>
      <div className={`w-8 h-4 rounded-full relative transition-colors ${active ? 'bg-teal-500/30 border border-teal-400' : 'bg-white/10 border border-white/20'}`}>
        <div className={`absolute top-0.5 w-2.5 h-2.5 rounded-full shadow-sm transition-all ${active ? 'bg-teal-400 left-[18px]' : 'bg-slate-400 left-1'}`}></div>
      </div>
    </label>
  );
}
