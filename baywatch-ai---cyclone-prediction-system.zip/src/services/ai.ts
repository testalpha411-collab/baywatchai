import { GoogleGenAI } from "@google/genai";

// Initialize SDK
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface CycloneData {
  cyclone_name: string;
  intensity: string;
  landfall: string;
  eta: string;
  path: [number, number][];
}

function extractJSON(text: string) {
  const match = text.match(/{[\s\S]*}/);
  if (match) {
    return JSON.parse(match[0]);
  }
  return JSON.parse(text);
}

export async function getAIData(): Promise<CycloneData | null> {
  const prompt = `
You are a cyclone prediction system.

Given:
Wind speed: 110 km/h
Pressure: 980 hPa
Direction: Northwest
Current Location: Bay of Bengal (approx 13.0, 84.0)

Return JSON:
{
  "cyclone_name": "Name of cyclone",
  "intensity": "Category X",
  "landfall": "Location",
  "eta": "Time",
  "path": [[lat, lng], [lat, lng], ...] // Provide 5 realistic coordinates heading northwest towards Chennai/Andhra coast starting from 13.0, 84.0
}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });
    
    if (response.text) {
      return extractJSON(response.text) as CycloneData;
    }
    return null;
  } catch (e: any) {
    // Suppress console error for quota limits to avoid cluttering the console,
    // and gracefully fall back to mock data.
    return {
      cyclone_name: "Cyclone Michaung (Mock)",
      intensity: "Category 3",
      landfall: "Chennai Coast",
      eta: "Tomorrow, 14:00 IST",
      path: [
        [13.0, 84.0],
        [13.2, 83.5],
        [13.5, 82.8],
        [13.8, 81.5],
        [14.0, 80.2]
      ]
    };
  }
}
