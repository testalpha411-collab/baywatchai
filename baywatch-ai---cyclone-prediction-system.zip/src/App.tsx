/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { onAuthStateChanged, User } from "firebase/auth";
import { auth } from "./firebase";
import { AppLayout } from "./layouts/AppLayout";
import { Dashboard } from "./pages/Dashboard";
import { ImpactMap } from "./pages/ImpactMap";
import { PredictiveModels } from "./pages/PredictiveModels";
import { EmergencyResponse } from "./pages/EmergencyResponse";
import { Auth } from "./pages/Auth";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0a0a0a] text-teal-400">
        <div className="animate-pulse">Initializing Secure Connection...</div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/auth" element={!user ? <Auth /> : <Navigate to="/" />} />
        <Route path="/" element={user ? <AppLayout /> : <Navigate to="/auth" />}>
          <Route index element={<Dashboard />} />
          <Route path="impact" element={<ImpactMap />} />
          <Route path="models" element={<PredictiveModels />} />
          <Route path="emergency" element={<EmergencyResponse />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
